package com.rotuls.aipro;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    EditText input; TextView status;
    final String[] modules = {"AI CHAT","GENERATE GAMBAR","GENERATE VIDEO","GENERATE LAGU / AUDIO","SKRIPSI / MAKALAH","PRESENTASI (PPTX)","WORD / DOCX","EXCEL / XLSX"};

    @Override public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main);
        input=findViewById(R.id.input); status=findViewById(R.id.status);
        bind(R.id.chat,"AI Chat","Chat AI dengan model teks melalui provider API.");
        bind(R.id.image,"Generate Gambar","Membuat prompt gambar dan mengirimkannya ke provider image-generation yang dikonfigurasi.");
        bind(R.id.video,"Generate Video","Membuat prompt video dan meneruskannya ke provider video yang dikonfigurasi.");
        bind(R.id.music,"Generate Lagu / Audio","Membuat prompt musik/audio dan meneruskannya ke provider audio yang dikonfigurasi.");
        bind(R.id.thesis,"Skripsi / Makalah","Membuat outline, bab, daftar pustaka, dan draft berdasarkan topik yang kamu masukkan.");
        bind(R.id.presentation,"Presentasi (PPTX)","Menyusun struktur slide dan konten presentasi siap diekspor.");
        bind(R.id.word,"Word / DOCX","Menyusun dokumen terstruktur untuk diekspor menjadi DOCX.");
        bind(R.id.excel,"Excel / XLSX","Menyusun tabel, rumus, dan struktur spreadsheet untuk diekspor menjadi XLSX.");
        findViewById(R.id.generate).setOnClickListener(v -> generate());
        findViewById(R.id.settings).setOnClickListener(v -> settingsDialog());
    }
    void bind(int id, String title, String desc){
        findViewById(id).setOnClickListener(v -> {
            status.setText(title+"\n\n"+desc+"\n\nMasukkan detail di kolom prompt lalu tekan GENERATE.");
            input.requestFocus();
        });
    }
    void generate(){
        String p=input.getText().toString().trim();
        if(p.isEmpty()){ Toast.makeText(this,"Isi prompt dulu.",Toast.LENGTH_SHORT).show(); return; }
        status.setText("REQUEST SIAP\n\n"+p+"\n\nProvider akan digunakan sesuai pengaturan API.");
    }
    void settingsDialog(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(30,10,30,10);
        String[] names={"OpenRouter / Text AI","Image Provider","Video Provider","Music / Audio Provider"};
        for(String n:names){ EditText e=new EditText(this); e.setHint(n+" endpoint / API key"); box.addView(e); }
        new AlertDialog.Builder(this).setTitle("API & PROVIDER SETTINGS").setView(box)
        .setMessage("Fitur generasi gambar, video, dan musik membutuhkan provider/API yang memang mendukung jenis media tersebut. OpenRouter terutama digunakan untuk model AI yang tersedia di sana.")
        .setPositiveButton("SIMPAN",null).show();
    }
}