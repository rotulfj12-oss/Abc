# ROTUL'S AI PRO ULTRA
Android Studio project, v2.0.

Modul UI:
- AI Chat
- Generate gambar
- Generate video
- Generate lagu/audio
- Skripsi/makalah
- Presentasi PPTX
- Word/DOCX
- Excel/XLSX
- Provider/API settings

PENTING:
UI dan arsitektur modul sudah disiapkan, tetapi video/music/image generation membutuhkan API/provider yang benar-benar menyediakan model tersebut. Jangan menganggap satu API key OpenRouter otomatis dapat membuat semua jenis media.

Project ini sengaja tidak memasukkan API key pengguna. Masukkan key milik sendiri di aplikasi/provider yang dipilih.
